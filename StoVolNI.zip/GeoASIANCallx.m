% Control Variate - Takehome Exam Question - Nick Irrer
function [Price, CI, Quality] = GeoASIANCallx(S,K,r,q,vol,T,N,NPaths1,NPaths2)
rng(0);
Underlying = GBMPaths(S,r,q,vol,T,N,NPaths1);
AVEPrice = mean(Underlying(:,1:N+1) , 2);
GEOPrice = geomean(Underlying(:,1:N+1) , 2);
% X
Intrinsic = exp(-r*T)*max(0,AVEPrice - K);
% Y
GeoIntrinsic = exp(-r*T)*max(0,GEOPrice - K);
% Approximate c
SampleCov = cov(Intrinsic,GeoIntrinsic);
c = SampleCov(1,2)/var(Intrinsic);
%
% First random discarded to avoid bias
Underlying = GBMPaths(S,r,q,vol,T,N,NPaths2);
GEOPrice = geomean(Underlying(:,1:N+1) , 2);
% X
GeoIntrinsic = exp(-r*T)*max(0,GEOPrice - K);
% Y
SUMPrice = sum(Underlying, 2);
%E(Y)
dT=T/N;
ExpectedSUM = S*(1-exp(r*dT*(N+1)))/(1-exp(r*dT));
%X - c(y - E(Y))
ControlVar = GeoIntrinsic - c*(SUMPrice - ExpectedSUM);
[Price, XX, CI] = normfit(ControlVar);
Quality = (CI(2)-CI(1))/Price/2;
end
